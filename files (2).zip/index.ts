/**
 * Checko Telegram Bot — Cloudflare Worker
 *
 * Команды:
 *   /start        — приветствие
 *   /help         — справка
 *   /inn <ИНН>    — полная проверка контрагента
 *   /finance <ИНН> — финансовая отчётность
 *   /courts <ИНН> — арбитражные дела
 *   /fssp <ИНН>   — исполнительные производства ФССП
 *   /contracts <ИНН> — госзакупки
 *   /inspections <ИНН> — проверки Генпрокуратуры
 *   /bankruptcy <ИНН>  — записи ЕФРСБ (банкротства)
 *   /person <ИНН>      — физлицо (связи, риски)
 *   /bank <БИК>        — информация о банке
 *   /timeline <ИНН>    — история изменений
 *
 * Также: просто отправить ИНН (10 или 12 цифр) → авто-проверка
 *
 * Secrets (wrangler secret put):
 *   TELEGRAM_BOT_TOKEN, CHECKO_API_KEY, WEBHOOK_SECRET
 */

// ── Types ──────────────────────────────────────────────────

interface Env {
  TELEGRAM_BOT_TOKEN: string;
  CHECKO_API_KEY: string;
  WEBHOOK_SECRET: string;
}

interface TelegramUpdate {
  message?: {
    chat: { id: number };
    text?: string;
    from?: { first_name?: string };
  };
}

// ── Checko API client ──────────────────────────────────────

const CHECKO = "https://api.checko.ru/v2";

async function checko(endpoint: string, key: string, params: Record<string, string>): Promise<any> {
  const url = new URL(`${CHECKO}/${endpoint}`);
  url.searchParams.set("key", key);
  for (const [k, v] of Object.entries(params)) {
    if (v) url.searchParams.set(k, v);
  }
  const r = await fetch(url.toString(), { headers: { Accept: "application/json" } });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  const json: any = await r.json();
  if (json.meta?.status === "error") throw new Error(json.meta.message || "Checko error");
  return json;
}

// ── Telegram helpers ───────────────────────────────────────

async function tg(token: string, method: string, body: Record<string, unknown>): Promise<void> {
  await fetch(`https://api.telegram.org/bot${token}/${method}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

async function reply(token: string, chatId: number, text: string, parse_mode = "HTML"): Promise<void> {
  // Telegram ограничивает 4096 символов
  const chunks: string[] = [];
  let remaining = text;
  while (remaining.length > 0) {
    if (remaining.length <= 4000) {
      chunks.push(remaining);
      break;
    }
    let cut = remaining.lastIndexOf("\n", 4000);
    if (cut < 200) cut = 4000;
    chunks.push(remaining.slice(0, cut));
    remaining = remaining.slice(cut);
  }
  for (const chunk of chunks) {
    await tg(token, "sendMessage", { chat_id: chatId, text: chunk, parse_mode, disable_web_page_preview: true });
  }
}

async function typing(token: string, chatId: number): Promise<void> {
  await tg(token, "sendChatAction", { chat_id: chatId, action: "typing" });
}

// ── Formatters (из PDF-документации API 2.4) ──────────────

function esc(s: unknown): string {
  if (s === null || s === undefined) return "—";
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function money(v: unknown): string {
  if (v === null || v === undefined) return "—";
  const n = Number(v);
  if (isNaN(n)) return String(v);
  return n.toLocaleString("ru-RU", { maximumFractionDigits: 0 }) + " ₽";
}

function fmtCompanyShort(d: any): string {
  if (!d) return "";
  const status = d.Статус?.Наим || d.Статус || "—";
  const lines = [
    `<b>${esc(d.НаимСокр || d.НаимПолн || d.name)}</b>`,
    `ИНН: <code>${esc(d.ИНН || d.inn)}</code>  ОГРН: <code>${esc(d.ОГРН || d.ogrn)}</code>`,
    `КПП: ${esc(d.КПП || d.kpp)}`,
    `📅 Регистрация: ${esc(d.ДатаРег || d.reg_date)}`,
    `📊 Статус: ${esc(status)}`,
  ];
  if (d.ДатаЛикв) lines.push(`☠️ Ликвидация: ${esc(d.ДатаЛикв)}`);
  if (d.ЮрАдрес) lines.push(`📍 ${esc(d.ЮрАдрес)}`);
  if (d.ОКВЭД) {
    const okved = typeof d.ОКВЭД === "object" ? `${d.ОКВЭД.Код} ${d.ОКВЭД.Наим}` : d.ОКВЭД;
    lines.push(`🏭 ОКВЭД: ${esc(okved)}`);
  }
  return lines.join("\n");
}

function fmtRisks(d: any): string {
  const risks: string[] = [];
  if (d.ФактРиск || d.РискФакторы) {
    const rf = d.ФактРиск || d.РискФакторы || {};
    if (rf.МассАдрес) risks.push("⚠️ Массовый адрес регистрации");
    if (rf.МассРуковод) risks.push("⚠️ Массовый руководитель");
    if (rf.МассУчред) risks.push("⚠️ Массовый учредитель");
    if (rf.НедобПост) risks.push("🚫 Реестр недобросовестных поставщиков");
    if (rf.Санкции) risks.push(`🔒 Санкции: ${esc(rf.СанкцииСтраны?.join(", "))}`);
  }
  // Поля на верхнем уровне data
  if (d.МассАдрес) risks.push("⚠️ Массовый адрес");
  if (d.МассРуковод) risks.push("⚠️ Массовый руководитель");
  if (d.МассУчред) risks.push("⚠️ Массовый учредитель");
  if (d.НедобПост) risks.push("🚫 Реестр недобросовестных поставщиков");
  if (d.Санкции) risks.push(`🔒 Санкции: ${esc(d.СанкцииСтраны?.join(", "))}`);

  if (risks.length === 0) return "✅ Факторов риска не обнаружено";
  return "<b>⚠️ ФАКТОРЫ РИСКА:</b>\n" + risks.join("\n");
}

function fmtLeaders(d: any): string {
  const leaders = d.Руковод || d.Руководители || [];
  if (!Array.isArray(leaders) || leaders.length === 0) return "";
  const items = leaders.slice(0, 5).map((l: any) =>
    `👤 ${esc(l.ФИО || l.Наим)} — ${esc(l.Долж || l.Должн || "руководитель")}`
  );
  return "\n<b>Руководители:</b>\n" + items.join("\n");
}

function fmtFounders(d: any): string {
  const founders = d.Учред || d.Учредители || [];
  if (!Array.isArray(founders) || founders.length === 0) return "";
  const items = founders.slice(0, 5).map((f: any) => {
    const name = f.ФИО || f.Наим || f.НаимПолн || "—";
    const share = f.Доля?.Процент || f.ДоляПроц;
    return `👥 ${esc(name)}${share ? ` (${share}%)` : ""}`;
  });
  return "\n<b>Учредители:</b>\n" + items.join("\n");
}

// ── Command handlers ───────────────────────────────────────

async function cmdInn(inn: string, env: Env, chatId: number): Promise<string> {
  const json = await checko("company", env.CHECKO_API_KEY, { inn });
  const d = json.data;
  if (!d) return "❌ Организация не найдена по ИНН " + inn;

  let text = "🏢 <b>ПРОВЕРКА КОНТРАГЕНТА</b>\n\n";
  text += fmtCompanyShort(d) + "\n";
  text += fmtLeaders(d);
  text += fmtFounders(d);
  text += "\n\n" + fmtRisks(d);

  // Контакты
  const contacts: string[] = [];
  if (d.Телефоны?.length) contacts.push(`📞 ${d.Телефоны.slice(0, 3).join(", ")}`);
  if (d.Email?.length) contacts.push(`📧 ${d.Email.slice(0, 2).join(", ")}`);
  if (d.Сайты?.length) contacts.push(`🌐 ${d.Сайты.slice(0, 2).join(", ")}`);
  if (contacts.length) text += "\n\n<b>Контакты:</b>\n" + contacts.join("\n");

  // МСП
  if (d.МСП) {
    text += `\n\n📋 МСП: ${esc(d.МСП.Категория || d.МСП)} (${esc(d.МСП.Числ || d.СрЧисл || "—")} чел.)`;
  }

  text += `\n\n🔗 <a href="https://checko.ru/company/${inn}">Полный профиль на Checko</a>`;
  text += "\n\nДополнительно:\n";
  text += `/finance ${inn} — финансы\n`;
  text += `/courts ${inn} — арбитраж\n`;
  text += `/fssp ${inn} — ФССП\n`;
  text += `/contracts ${inn} — госзакупки\n`;
  text += `/inspections ${inn} — проверки\n`;
  text += `/bankruptcy ${inn} — банкротство\n`;
  text += `/timeline ${inn} — история изменений`;

  return text;
}

async function cmdInnIp(inn: string, env: Env): Promise<string> {
  const json = await checko("entrepreneur", env.CHECKO_API_KEY, { inn });
  const d = json.data;
  if (!d) return "❌ ИП не найден по ИНН " + inn;

  let text = "🧑‍💼 <b>ИП</b>\n\n";
  text += `<b>${esc(d.ФИО)}</b> (${esc(d.ТипСокр || d.Тип)})\n`;
  text += `ИНН: <code>${esc(d.ИНН)}</code>  ОГРНИП: <code>${esc(d.ОГРНИП)}</code>\n`;
  text += `📅 Регистрация: ${esc(d.ДатаРег)}\n`;
  text += `📊 Статус: ${esc(d.Статус?.Наим || d.Статус)}\n`;
  if (d.Прекращ?.Дата) text += `☠️ Прекращение: ${esc(d.Прекращ.Дата)} — ${esc(d.Прекращ.Наим)}\n`;
  if (d.ОКВЭД) text += `🏭 ОКВЭД: ${esc(d.ОКВЭД.Код)} ${esc(d.ОКВЭД.Наим)}\n`;
  text += "\n" + fmtRisks(d);
  text += `\n\n🔗 <a href="https://checko.ru/entrepreneur/${inn}">Профиль на Checko</a>`;
  return text;
}

async function cmdFinance(inn: string, env: Env): Promise<string> {
  const json = await checko("finances", env.CHECKO_API_KEY, { inn });
  const d = json.data;
  if (!d || Object.keys(d).length === 0) return "❌ Финансовая отчётность не найдена для ИНН " + inn;

  let text = "📊 <b>ФИНАНСОВАЯ ОТЧЁТНОСТЬ</b>\n";
  if (json.company) text += fmtCompanyShort(json.company) + "\n\n";

  // Строки: 2110=выручка, 2400=чистая прибыль, 1600=активы, 1300=капитал
  const years = Object.keys(d).filter(k => /^\d{4}$/.test(k)).sort().reverse().slice(0, 5);
  for (const year of years) {
    const y = d[year];
    if (!y) continue;
    text += `<b>${year}:</b>\n`;
    if (y["2110"] !== undefined) text += `  Выручка: ${money(y["2110"] * 1000)}\n`;
    if (y["2400"] !== undefined) text += `  Чистая прибыль: ${money(y["2400"] * 1000)}\n`;
    if (y["1600"] !== undefined) text += `  Активы: ${money(y["1600"] * 1000)}\n`;
    if (y["1300"] !== undefined) text += `  Капитал: ${money(y["1300"] * 1000)}\n`;
  }

  if (json["bo.nalog.ru"]?.Отчет) {
    text += "\n📄 PDF-отчёты bo.nalog.ru:\n";
    const reports = json["bo.nalog.ru"].Отчет;
    for (const [yr, url] of Object.entries(reports).reverse().slice(0, 3)) {
      text += `  <a href="${url}">${yr}</a>\n`;
    }
  }
  return text;
}

async function cmdCourts(inn: string, env: Env): Promise<string> {
  const json = await checko("legal-cases", env.CHECKO_API_KEY, { inn, sort: "-date", limit: "10" });
  const d = json.data;
  if (!d?.Записи?.length) return "✅ Арбитражных дел не найдено для ИНН " + inn;

  let text = `⚖️ <b>АРБИТРАЖНЫЕ ДЕЛА</b> (${d.ЗапВсего} шт., сумма исков: ${money(d.ОбщСуммИск)})\n`;
  if (json.company) text += `${esc(json.company.НаимСокр)}\n\n`;

  for (const c of d.Записи.slice(0, 7)) {
    text += `📂 <b>${esc(c.Номер)}</b> от ${esc(c.Дата)}\n`;
    text += `  Суд: ${esc(c.Суд)}\n`;
    if (c.СуммИск) text += `  Сумма: ${money(c.СуммИск)}\n`;
    if (c.СтрКАД) text += `  <a href="${c.СтрКАД}">КАД</a>\n`;
    text += "\n";
  }
  if (d.ЗапВсего > 7) text += `\n... и ещё ${d.ЗапВсего - 7} дел`;
  return text;
}

async function cmdFssp(inn: string, env: Env): Promise<string> {
  const json = await checko("enforcements", env.CHECKO_API_KEY, { inn, sort: "-date", limit: "10" });
  const d = json.data;
  if (!d?.Записи?.length) return "✅ Исполнительных производств не найдено для ИНН " + inn;

  let text = `🔨 <b>ИСПОЛНИТЕЛЬНЫЕ ПРОИЗВОДСТВА ФССП</b>\n`;
  if (json.company) text += `${esc(json.company.НаимСокр)}\n\n`;

  let totalDebt = 0;
  for (const e of d.Записи.slice(0, 7)) {
    const debt = Number(e.СумДолг) || 0;
    totalDebt += debt;
    text += `📋 ${esc(e.ИспПрНомер)} от ${esc(e.ИспПрДата)}\n`;
    text += `  Долг: ${money(e.СумДолг)} | Остаток: ${money(e.ОстЗадолж)}\n`;
    text += `  ${esc(e.ПредмИсп?.slice(0, 100))}\n\n`;
  }
  text = `${text.trim()}\n\n💰 Общий долг (показано): ${money(totalDebt)}`;
  return text;
}

async function cmdContracts(inn: string, env: Env): Promise<string> {
  const json = await checko("contracts", env.CHECKO_API_KEY, {
    inn, law: "44", role: "supplier", sort: "-date", limit: "10"
  });
  const d = json.data;
  if (!d?.Записи?.length) return "📭 Контрактов по 44-ФЗ (поставщик) не найдено для ИНН " + inn;

  let text = `📋 <b>ГОСЗАКУПКИ 44-ФЗ</b> (${d.ЗапВсего} контрактов)\n`;
  if (json.company) text += `${esc(json.company.НаимСокр)}\n\n`;

  for (const c of d.Записи.slice(0, 7)) {
    text += `📄 ${esc(c.РегНомер)} от ${esc(c.Дата)}\n`;
    text += `  💰 ${money(c.Цена)}\n`;
    text += `  ${esc(c.Предмет?.slice(0, 120))}\n`;
    if (c.СтрЕИС) text += `  <a href="${c.СтрЕИС}">ЕИС</a>\n`;
    text += "\n";
  }
  return text;
}

async function cmdInspections(inn: string, env: Env): Promise<string> {
  const json = await checko("inspections", env.CHECKO_API_KEY, { inn, sort: "-date", limit: "10" });
  const d = json.data;
  if (!d?.Записи?.length) return "✅ Проверок не найдено для ИНН " + inn;

  let text = `🔍 <b>ПРОВЕРКИ</b> (${d.ЗапВсего} шт.)\n`;
  if (json.company) text += `${esc(json.company.НаимСокр)}\n\n`;

  for (const p of d.Записи.slice(0, 5)) {
    text += `📝 №${esc(p.Номер)} | ${esc(p.ТипПров)} | ${esc(p.ТипРасп)}\n`;
    text += `  ${esc(p.ДатаНач)} — ${esc(p.ДатаОконч)}\n`;
    if (p.Наруш) text += `  ❗ Нарушения обнаружены\n`;
    if (p.ОргКонтр?.Наим) text += `  Орган: ${esc(p.ОргКонтр.Наим.slice(0, 80))}\n`;
    text += "\n";
  }
  return text;
}

async function cmdBankruptcy(inn: string, env: Env): Promise<string> {
  const json = await checko("bankruptcy-messages", env.CHECKO_API_KEY, { inn, sort: "-date", limit: "10" });
  const d = json.data;
  if (!d?.Записи?.length) return "✅ Записей ЕФРСБ не найдено для ИНН " + inn;

  let text = `💀 <b>ЗАПИСИ ЕФРСБ (БАНКРОТСТВО)</b> (${d.ЗапВсего} шт.)\n`;
  if (json.company) text += `${esc(json.company.НаимСокр)}\n\n`;

  for (const m of d.Записи.slice(0, 7)) {
    text += `📌 ${esc(m.Дата)} — ${esc(m.ТипНаим)}\n`;
    if (m.НомерДела) text += `  Дело: ${esc(m.НомерДела)}\n`;
    if (m.URL) text += `  <a href="${m.URL}">Федресурс</a>\n`;
    text += "\n";
  }
  return text;
}

async function cmdPerson(inn: string, env: Env): Promise<string> {
  const json = await checko("person", env.CHECKO_API_KEY, { inn });
  const d = json.data;
  if (!d) return "❌ Физлицо не найдено по ИНН " + inn;

  let text = `👤 <b>ФИЗИЧЕСКОЕ ЛИЦО</b>\n`;
  text += `${esc(d.ФИО)} | ИНН: <code>${esc(d.ИНН)}</code>\n\n`;

  if (d.Руковод?.length) {
    text += `<b>Руководитель в ${d.Руковод.length} орг.:</b>\n`;
    for (const o of d.Руковод.slice(0, 5)) {
      text += `  🏢 ${esc(o.НаимСокр)} (${esc(o.Статус)})\n`;
    }
  }
  if (d.Учред?.length) {
    text += `\n<b>Учредитель в ${d.Учред.length} орг.:</b>\n`;
    for (const o of d.Учред.slice(0, 5)) {
      text += `  🏢 ${esc(o.НаимСокр)} (${esc(o.Статус)})\n`;
    }
  }
  if (d.ИП?.length) {
    text += `\n<b>ИП:</b>\n`;
    for (const ip of d.ИП.slice(0, 3)) {
      text += `  🧑‍💼 ${esc(ip.ФИО)} — ${esc(ip.Статус)} (${esc(ip.ОГРНИП)})\n`;
    }
  }

  text += "\n" + fmtRisks(d);
  return text;
}

async function cmdBank(bic: string, env: Env): Promise<string> {
  const json = await checko("bank", env.CHECKO_API_KEY, { bic });
  const d = json.data;
  if (!d) return "❌ Банк не найден по БИК " + bic;

  let text = `🏦 <b>БАНК</b>\n`;
  text += `${esc(d.Наим)}\n`;
  text += `БИК: <code>${esc(d.БИК)}</code>\n`;
  if (d.НаимАнгл) text += `EN: ${esc(d.НаимАнгл)}\n`;
  text += `📍 ${esc(d.Адрес)}\n`;
  text += `Тип: ${esc(d.Тип)}\n`;
  if (d.КорСчет) text += `К/с: ${esc(d.КорСчет.Номер)} от ${esc(d.КорСчет.Дата)}\n`;
  return text;
}

async function cmdTimeline(inn: string, env: Env): Promise<string> {
  const json = await checko("timeline", env.CHECKO_API_KEY, { inn });
  const d = json.data;
  if (!d || !Array.isArray(d) || d.length === 0) return "📭 История изменений пуста для ИНН " + inn;

  let text = `📜 <b>ИСТОРИЯ ИЗМЕНЕНИЙ</b>\n`;
  if (json.company) text += `${esc(json.company.НаимСокр)}\n\n`;

  for (const ev of d.slice(0, 15)) {
    text += `📅 ${esc(ev.Дата)} — ${esc(ev.Событие)}\n`;
  }
  if (d.length > 15) text += `\n... и ещё ${d.length - 15} событий`;
  return text;
}

// ── Router ─────────────────────────────────────────────────

async function handleMessage(msg: TelegramUpdate["message"], env: Env): Promise<void> {
  if (!msg?.text || !msg.chat?.id) return;

  const chatId = msg.chat.id;
  const text = msg.text.trim();
  const token = env.TELEGRAM_BOT_TOKEN;

  // Parse command
  const cmdMatch = text.match(/^\/(\w+)\s*(.*)/);
  const cmd = cmdMatch ? cmdMatch[1].toLowerCase() : null;
  const arg = cmdMatch ? cmdMatch[2].trim() : "";

  // Bare INN detection (10 or 12 digits)
  const bareInn = text.match(/^(\d{10}|\d{12})$/);

  try {
    await typing(token, chatId);

    if (cmd === "start") {
      await reply(token, chatId,
        `👋 <b>Checko Bot — проверка контрагентов</b>\n\n` +
        `Отправьте ИНН (10 цифр — организация, 12 цифр — ИП) или используйте команды.\n\n` +
        `/help — полный список команд\n\n` +
        `Данные: ЕГРЮЛ, ЕГРИП, ФНС, ФССП, КАД, Генпрокуратура, ЕФРСБ, Федресурс\n` +
        `API: checko.ru v2.4`
      );
    } else if (cmd === "help") {
      await reply(token, chatId,
        `📖 <b>Команды:</b>\n\n` +
        `/inn &lt;ИНН&gt; — полная проверка организации\n` +
        `/finance &lt;ИНН&gt; — финансовая отчётность\n` +
        `/courts &lt;ИНН&gt; — арбитражные дела\n` +
        `/fssp &lt;ИНН&gt; — исполнительные производства\n` +
        `/contracts &lt;ИНН&gt; — госзакупки 44-ФЗ\n` +
        `/inspections &lt;ИНН&gt; — проверки Генпрокуратуры\n` +
        `/bankruptcy &lt;ИНН&gt; — ЕФРСБ (банкротства)\n` +
        `/person &lt;ИНН 12 цифр&gt; — физлицо\n` +
        `/bank &lt;БИК&gt; — информация о банке\n` +
        `/timeline &lt;ИНН&gt; — история изменений\n\n` +
        `Или просто отправьте ИНН — авто-определение.`
      );
    } else if (cmd === "inn" && arg) {
      if (arg.length === 12) {
        await reply(token, chatId, await cmdInnIp(arg, env));
      } else {
        await reply(token, chatId, await cmdInn(arg, env, chatId));
      }
    } else if (cmd === "finance" && arg) {
      await reply(token, chatId, await cmdFinance(arg, env));
    } else if (cmd === "courts" && arg) {
      await reply(token, chatId, await cmdCourts(arg, env));
    } else if (cmd === "fssp" && arg) {
      await reply(token, chatId, await cmdFssp(arg, env));
    } else if (cmd === "contracts" && arg) {
      await reply(token, chatId, await cmdContracts(arg, env));
    } else if (cmd === "inspections" && arg) {
      await reply(token, chatId, await cmdInspections(arg, env));
    } else if (cmd === "bankruptcy" && arg) {
      await reply(token, chatId, await cmdBankruptcy(arg, env));
    } else if (cmd === "person" && arg) {
      await reply(token, chatId, await cmdPerson(arg, env));
    } else if (cmd === "bank" && arg) {
      await reply(token, chatId, await cmdBank(arg, env));
    } else if (cmd === "timeline" && arg) {
      await reply(token, chatId, await cmdTimeline(arg, env));
    } else if (bareInn) {
      const inn = bareInn[1];
      if (inn.length === 12) {
        // Сначала пробуем как ИП, если ошибка — как физлицо
        try {
          await reply(token, chatId, await cmdInnIp(inn, env));
        } catch {
          await reply(token, chatId, await cmdPerson(inn, env));
        }
      } else {
        await reply(token, chatId, await cmdInn(inn, env, chatId));
      }
    } else if (cmd && arg) {
      await reply(token, chatId, `❓ Неизвестная команда. /help — список команд.`);
    }
  } catch (err: any) {
    const errMsg = err?.message || "Unknown error";
    await reply(token, chatId, `❌ Ошибка: ${esc(errMsg)}\n\nПроверьте ИНН и попробуйте снова.`);
  }
}

// ── Worker entry ───────────────────────────────────────────

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);

    // Health check
    if (url.pathname === "/" || url.pathname === "/health") {
      return new Response(JSON.stringify({
        status: "ok",
        bot: "checko-telegram-bot",
        api: "checko.ru v2.4",
        commands: ["/start","/help","/inn","/finance","/courts","/fssp",
                   "/contracts","/inspections","/bankruptcy","/person","/bank","/timeline"]
      }), { headers: { "Content-Type": "application/json" } });
    }

    // Set webhook helper
    if (url.pathname === "/setup-webhook") {
      const workerUrl = `${url.protocol}//${url.host}/webhook/${env.WEBHOOK_SECRET}`;
      const tgUrl = `https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/setWebhook?url=${encodeURIComponent(workerUrl)}`;
      const resp = await fetch(tgUrl);
      const result = await resp.json();
      return new Response(JSON.stringify(result, null, 2), {
        headers: { "Content-Type": "application/json" }
      });
    }

    // Delete webhook
    if (url.pathname === "/delete-webhook") {
      const resp = await fetch(`https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/deleteWebhook`);
      const result = await resp.json();
      return new Response(JSON.stringify(result, null, 2), {
        headers: { "Content-Type": "application/json" }
      });
    }

    // Webhook endpoint
    if (request.method === "POST" && url.pathname === `/webhook/${env.WEBHOOK_SECRET}`) {
      const update: TelegramUpdate = await request.json();
      if (update.message) {
        // Non-blocking — respond 200 immediately, process in background
        const ctx = { waitUntil: (p: Promise<unknown>) => p };
        try {
          // @ts-ignore — ExecutionContext available in Workers
          const execCtx = arguments[2] as ExecutionContext;
          execCtx.waitUntil(handleMessage(update.message, env));
        } catch {
          await handleMessage(update.message, env);
        }
      }
      return new Response("ok");
    }

    return new Response("Not found", { status: 404 });
  },
} satisfies ExportedHandler<Env>;
