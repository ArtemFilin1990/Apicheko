# Checko Telegram Bot — Cloudflare Workers

Telegram-бот для проверки российских контрагентов через [Checko.ru API v2.4](https://checko.ru/integration/api).

## Возможности

| Команда | Описание | Источник |
|---------|----------|----------|
| `/inn <ИНН>` | Полная проверка организации/ИП | ЕГРЮЛ/ЕГРИП |
| `/finance <ИНН>` | Финансовая отчётность | ФНС + Росстат |
| `/courts <ИНН>` | Арбитражные дела | КАД |
| `/fssp <ИНН>` | Исполнительные производства | ФССП |
| `/contracts <ИНН>` | Госзакупки 44-ФЗ | ЕИС |
| `/inspections <ИНН>` | Проверки | Генпрокуратура |
| `/bankruptcy <ИНН>` | Банкротства | ЕФРСБ |
| `/person <ИНН>` | Физлицо (связи, риски) | ЕГРЮЛ/ЕГРИП |
| `/bank <БИК>` | Банк по БИК | ЦБ РФ |
| `/timeline <ИНН>` | История изменений | ЕГРЮЛ/ЕГРИП |

Также: отправьте просто **ИНН** (10 или 12 цифр) → автоматическое определение организации или ИП.

## Деплой

### 1. Подготовка

```bash
# Клонировать / скопировать проект
cd checko-tg-worker

# Установить зависимости
npm install
```

### 2. Секреты

Получите:
- **TELEGRAM_BOT_TOKEN** — у [@BotFather](https://t.me/BotFather) (`/newbot`)
- **CHECKO_API_KEY** — в [ЛК checko.ru](https://checko.ru/cabinet) (бесплатно 100 запросов/день)
- **WEBHOOK_SECRET** — произвольная строка (например, `openssl rand -hex 32`)

```bash
npx wrangler secret put TELEGRAM_BOT_TOKEN
npx wrangler secret put CHECKO_API_KEY
npx wrangler secret put WEBHOOK_SECRET
```

### 3. Деплой на Cloudflare

```bash
npx wrangler deploy
```

Вы получите URL вида: `https://checko-telegram-bot.<account>.workers.dev`

### 4. Установить Webhook

Откройте в браузере:
```
https://checko-telegram-bot.<account>.workers.dev/setup-webhook
```

Или вызовите curl:
```bash
curl https://checko-telegram-bot.<account>.workers.dev/setup-webhook
```

Ответ должен содержать `"ok": true`.

### 5. Проверка

Отправьте боту в Telegram:
```
7707049388
```
(ИНН ПАО «Ростелеком» — для теста)

## Архитектура

```
Telegram → Webhook (POST) → Cloudflare Worker → Checko API v2.4
                                                      ↓
                                            JSON response
                                                      ↓
                                      Format → Telegram sendMessage
```

- **Без polling** — webhook, ~50ms latency
- **Без базы данных** — stateless Worker
- **waitUntil** — мгновенный 200 OK, обработка в фоне
- **Auto-chunking** — длинные ответы разбиваются на сообщения ≤4000 символов

## Endpoints Worker

| Path | Описание |
|------|----------|
| `GET /` | Health check (JSON) |
| `GET /setup-webhook` | Установить Telegram webhook |
| `GET /delete-webhook` | Удалить webhook |
| `POST /webhook/{secret}` | Webhook endpoint для Telegram |

## Локальная разработка

```bash
npm start
# → http://localhost:8787

# В другом терминале — тест:
curl -X POST http://localhost:8787/webhook/test \
  -H "Content-Type: application/json" \
  -d '{"message":{"chat":{"id":123},"text":"/inn 7707049388"}}'
```

## Лимиты

- Checko бесплатно: **100 запросов/день**
- Checko сверх лимита: **0.30 ₽/запрос**
- Cloudflare Workers Free: **100,000 запросов/день**
- Telegram Bot API: без жёстких лимитов на webhook

## Структура проекта

```
checko-tg-worker/
├── src/
│   └── index.ts          # Всё в одном файле: worker + checko client + telegram + formatters
├── package.json
├── tsconfig.json
├── wrangler.jsonc         # Cloudflare config
└── README.md
```

## Для Эверест

Бот оптимизирован под задачи B2B-проверки контрагентов:
- Факторы риска (массовый адрес/руководитель/учредитель, недобросовестный поставщик, санкции)
- Финансовая динамика (выручка, прибыль по годам)
- Судебная нагрузка (арбитраж + ФССП)
- Госзакупки (44-ФЗ как поставщик)
- Банкротство (ЕФРСБ)
- Связи физлица (руководство/учредительство в других компаниях)
