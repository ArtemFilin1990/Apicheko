---
name: checko-api
description: >
  Интеграция с Checko.ru API v2 — проверка контрагентов по ИНН/ОГРН через ЕГРЮЛ/ЕГРИП,
  финансовая отчётность ФНС/Росстат, госзакупки 44-ФЗ/223-ФЗ, арбитражные дела КАД,
  исполнительные производства ФССП, проверки Генпрокуратуры, записи ЕФРСБ (банкротства),
  сообщения Федресурса, история изменений, поиск организаций и ИП.
  Используй этот скилл при любом запросе связанном с: Checko, checko.ru, api.checko.ru,
  проверка контрагента через Checko, ЕГРЮЛ API Checko, ЕГРИП Checko, финотчётность Checko,
  госзакупки контракты Checko, арбитраж Checko, ФССП Checko, исполнительные производства Checko,
  банкротство ЕФРСБ Checko, Федресурс Checko, поиск организаций Checko, история изменений Checko,
  KYC/AML через Checko, due diligence Checko, проверка поставщика Checko.
  Также активируй при интеграции Checko с Bitrix24, 1C, CRM, Telegram-ботами,
  FastAPI/webhook-обработчиками для обогащения данных контрагентов.
---

# Checko.ru API v2 — Skill

## Обзор

Checko.ru (портал «Чекко») — сервис проверки российских организаций и ИП.
API v2 предоставляет доступ к данным ЕГРЮЛ, ЕГРИП, ФНС, Росстата, ЕИС (госзакупки),
ФАС, ФССП, Картотеки арбитражных дел, Генпрокуратуры, ЕФРСБ и Федресурса.

**Текущая версия API: 2.4**

## Аутентификация

- API-ключ из личного кабинета checko.ru (после регистрации)
- Передаётся как параметр `key` в GET/POST запросах
- Бесплатный тариф: 100 запросов/день
- Поддержка HTTPS и HTTP (порт 80 — fallback для 1С при ошибке SSL)

## Base URL

```
https://api.checko.ru/v2/{method}
```

## Методы запросов

Поддерживаются GET и POST (JSON body).

### GET
```
https://api.checko.ru/v2/company?key={API_KEY}&inn={INN}
```

### POST
```bash
curl -X POST \
  -H "Content-Type: application/json" \
  -d '{"key": "{API_KEY}", "inn": "{INN}"}' \
  https://api.checko.ru/v2/company
```

## Endpoints (методы API)

| # | Endpoint | Описание | Ключевые параметры |
|---|----------|----------|--------------------|
| 1 | `/v2/company` | Организация (ЕГРЮЛ) | `inn`, `ogrn`, `source=true` |
| 2 | `/v2/entrepreneur` | ИП (ЕГРИП) | `inn`, `ogrnip`, `source=true` |
| 3 | `/v2/search` | Поиск | `by`, `obj`, `query`, `region`, `okved`, `opf`, `active` |
| 4 | `/v2/contracts` | Госзакупки (44-ФЗ/223-ФЗ) | `inn`, `law`, `role`, `sort`, `page` |
| 5 | `/v2/enforcements` | Исполнительные производства ФССП | `inn`, `ogrn` |
| 6 | `/v2/bankruptcy-messages` | Записи ЕФРСБ (банкротства) | `inn`, `ogrn`, `date_from`, `date_to` |
| 7 | `/v2/finance` | Финансовая отчётность (ФНС/Росстат) | `inn`, `ogrn` |
| 8 | `/v2/inspections` | Проверки Генпрокуратуры | `inn`, `ogrn` |
| 9 | `/v2/legal-cases` | Арбитражные дела (КАД) | `inn`, `ogrn`, `date_from`, `date_to` |
| 10 | `/v2/connections` | Связи (руководители/учредители) | `inn`, `ogrn` |
| 11 | `/v2/history` | История изменений | `inn`, `ogrn` |
| 12 | `/v2/fedresurs-messages` | Сообщения Федресурса | `inn`, `ogrn`, `date_from`, `date_to` |

> Для подробного описания полей ответа каждого endpoint — см. `references/endpoints-detail.md`

## Ответ API

Все ответы — JSON. Структура:

```json
{
  "meta": {
    "status": "ok",
    "message": null,
    "today_request_count": 42
  },
  "data": { ... }
}
```

- `meta.status` — `"ok"` или `"error"`
- `meta.message` — описание ошибки (null при успехе)
- `meta.today_request_count` — количество запросов за сегодня
- `data` — основные данные

## Endpoint: `/v2/company` (подробно)

Данные организации из ЕГРЮЛ. При `source=true` — добавляет raw XML→JSON из ФНС.

### Блоки данных в ответе

- **Реквизиты**: ИНН, КПП, ОГРН, дата регистрации, наименование, адрес
- **Статус**: действующая/ликвидирована/реорганизация
- **ОКВЭД**: основной + дополнительные (версия 2014)
- **Росстат**: ОКПО, ОКТМО, ОКОГУ, ОКАТО
- **Руководители**: ФИО, должность, ИНН, массовый руководитель (флаг), связи (ОГРН других орг.)
- **Учредители**: ФИО/наименование, доля, массовый учредитель (флаг), связи
- **Лицензии**: номер, дата, лицензирующий орган, виды деятельности
- **Подразделения**: филиалы, представительства
- **Контакты**: телефоны, email, сайт (из открытых источников)
- **Налоги**: спецрежимы, задолженности
- **Факторы риска**: массовый адрес, массовый руководитель/учредитель, реестр недобросовестных поставщиков, санкции
- **Связи**: ОГРН организаций, связанных через руководителей/учредителей

## Endpoint: `/v2/search` (подробно)

### Типы поиска (параметр `by`)

| `by` | Описание | Пример `query` |
|------|----------|----------------|
| `name` | По наименованию | `пао ростелеком` |
| `leader-name` | По ФИО руководителя | `греф герман оскарович` |
| `founder-name` | По ФИО учредителя | `нуралиев борис` |
| `okved` | По ОКВЭД | `63.11` |
| `reg-date` | По дате регистрации | `2021-12-09` |
| `upd-date` | По дате обновления в ЕГРЮЛ | `2022-01-27` |

### Фильтры

| Параметр | Описание |
|----------|----------|
| `obj` | `org` (организации) или `ent` (ИП) |
| `region` | Код региона (77 = Москва, 78 = СПб и т.д.) |
| `okved` | Фильтр по ОКВЭД (при поиске по дате) |
| `opf` | ОПФ (12300 = ООО и т.д.) |
| `active` | `true` — только действующие |

Максимум 100 результатов для поиска по наименованию, без ограничений для остальных типов.

## Endpoint: `/v2/contracts` (госзакупки)

| Параметр | Значения |
|----------|----------|
| `law` | `44` (44-ФЗ) или `223` (223-ФЗ) |
| `role` | `supplier` (поставщик) или `customer` (заказчик) |
| `sort` | `-date` (по дате ↓), `-price` (по цене ↓) |
| `page` | Номер страницы |

> **Ограничение**: с 2019 г. ЕИС не публикует данные поставщиков для 223-ФЗ.

## Endpoint: `/v2/enforcements` (ФССП)

Исполнительные производства. Поиск по наименованию/адресу (нечёткий поиск) — возможны ложные совпадения, т.к. ФССП не всегда указывает реквизиты.

## Endpoint: `/v2/bankruptcy-messages` (ЕФРСБ)

Записи из Единого федерального реестра сведений о банкротстве.

| Параметр | Описание |
|----------|----------|
| `date_from` | Начало периода (YYYY-MM-DD) |
| `date_to` | Конец периода (YYYY-MM-DD) |

## Python-клиент (production)

```python
"""Checko API v2 client для интеграции в Эверест-инфраструктуру."""
import httpx
import logging
from typing import Optional

logger = logging.getLogger(__name__)

class CheckoClient:
    """Async-клиент для Checko.ru API v2."""

    BASE_URL = "https://api.checko.ru/v2"

    def __init__(self, api_key: str, timeout: float = 15.0):
        self.api_key = api_key
        self.timeout = timeout
        self._client: Optional[httpx.AsyncClient] = None

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(timeout=self.timeout)
        return self._client

    async def _request(self, endpoint: str, **params) -> dict:
        """Универсальный GET-запрос к API."""
        params["key"] = self.api_key
        client = await self._get_client()
        url = f"{self.BASE_URL}/{endpoint}"
        try:
            resp = await client.get(url, params=params)
            resp.raise_for_status()
            data = resp.json()
            if data.get("meta", {}).get("status") == "error":
                msg = data.get("meta", {}).get("message", "Unknown error")
                logger.error("Checko API error: %s (endpoint=%s)", msg, endpoint)
                raise CheckoAPIError(msg)
            return data
        except httpx.HTTPStatusError as e:
            logger.error("HTTP error %s: %s", e.response.status_code, endpoint)
            raise
        except httpx.RequestError as e:
            logger.error("Request error: %s", e)
            raise

    # --- Основные методы ---

    async def get_company(self, inn: str = None, ogrn: str = None,
                          source: bool = False) -> dict:
        """Данные организации из ЕГРЮЛ."""
        params = {}
        if inn:
            params["inn"] = inn
        if ogrn:
            params["ogrn"] = ogrn
        if source:
            params["source"] = "true"
        return await self._request("company", **params)

    async def get_entrepreneur(self, inn: str = None, ogrnip: str = None,
                               source: bool = False) -> dict:
        """Данные ИП из ЕГРИП."""
        params = {}
        if inn:
            params["inn"] = inn
        if ogrnip:
            params["ogrnip"] = ogrnip
        if source:
            params["source"] = "true"
        return await self._request("entrepreneur", **params)

    async def search(self, by: str, query: str, obj: str = "org",
                     region: str = None, okved: str = None,
                     opf: str = None, active: bool = None) -> dict:
        """Поиск организаций/ИП."""
        params = {"by": by, "query": query, "obj": obj}
        if region:
            params["region"] = region
        if okved:
            params["okved"] = okved
        if opf:
            params["opf"] = opf
        if active is not None:
            params["active"] = str(active).lower()
        return await self._request("search", **params)

    async def get_contracts(self, inn: str, law: str = "44",
                            role: str = "supplier", sort: str = "-date",
                            page: int = None) -> dict:
        """Госзакупки (44-ФЗ / 223-ФЗ)."""
        params = {"inn": inn, "law": law, "role": role, "sort": sort}
        if page:
            params["page"] = str(page)
        return await self._request("contracts", **params)

    async def get_enforcements(self, inn: str = None, ogrn: str = None) -> dict:
        """Исполнительные производства ФССП."""
        params = {}
        if inn:
            params["inn"] = inn
        if ogrn:
            params["ogrn"] = ogrn
        return await self._request("enforcements", **params)

    async def get_bankruptcy_messages(self, inn: str = None, ogrn: str = None,
                                      date_from: str = None,
                                      date_to: str = None) -> dict:
        """Записи ЕФРСБ (банкротства)."""
        params = {}
        if inn:
            params["inn"] = inn
        if ogrn:
            params["ogrn"] = ogrn
        if date_from:
            params["date_from"] = date_from
        if date_to:
            params["date_to"] = date_to
        return await self._request("bankruptcy-messages", **params)

    async def get_finance(self, inn: str = None, ogrn: str = None) -> dict:
        """Финансовая отчётность (ФНС/Росстат)."""
        params = {}
        if inn:
            params["inn"] = inn
        if ogrn:
            params["ogrn"] = ogrn
        return await self._request("finance", **params)

    async def get_inspections(self, inn: str = None, ogrn: str = None) -> dict:
        """Проверки Генпрокуратуры."""
        params = {}
        if inn:
            params["inn"] = inn
        if ogrn:
            params["ogrn"] = ogrn
        return await self._request("inspections", **params)

    async def get_legal_cases(self, inn: str = None, ogrn: str = None,
                               date_from: str = None,
                               date_to: str = None) -> dict:
        """Арбитражные дела (КАД)."""
        params = {}
        if inn:
            params["inn"] = inn
        if ogrn:
            params["ogrn"] = ogrn
        if date_from:
            params["date_from"] = date_from
        if date_to:
            params["date_to"] = date_to
        return await self._request("legal-cases", **params)

    async def get_connections(self, inn: str = None, ogrn: str = None) -> dict:
        """Связи организации (через руководителей/учредителей)."""
        params = {}
        if inn:
            params["inn"] = inn
        if ogrn:
            params["ogrn"] = ogrn
        return await self._request("connections", **params)

    async def get_history(self, inn: str = None, ogrn: str = None) -> dict:
        """История изменений в ЕГРЮЛ/ЕГРИП."""
        params = {}
        if inn:
            params["inn"] = inn
        if ogrn:
            params["ogrn"] = ogrn
        return await self._request("history", **params)

    async def get_fedresurs_messages(self, inn: str = None, ogrn: str = None,
                                     date_from: str = None,
                                     date_to: str = None) -> dict:
        """Сообщения Федресурса."""
        params = {}
        if inn:
            params["inn"] = inn
        if ogrn:
            params["ogrn"] = ogrn
        if date_from:
            params["date_from"] = date_from
        if date_to:
            params["date_to"] = date_to
        return await self._request("fedresurs-messages", **params)

    async def close(self):
        if self._client and not self._client.is_closed:
            await self._client.aclose()


class CheckoAPIError(Exception):
    """Ошибка API Checko."""
    pass
```

## Интеграции

### Bitrix24 CRM (Эверест)
При создании/обновлении компании — вызов `get_company(inn=...)` для автозаполнения реквизитов, проверки факторов риска, связей. Webhook-обработчик на FastAPI.

### Telegram-бот
Бот принимает ИНН → вызывает `get_company` + `get_enforcements` + `get_legal_cases` → возвращает сводку по контрагенту.

### 1С
HTTP-сервис → GET на `api.checko.ru/v2/company?key=...&inn=...`.
При ошибке SSL → использовать HTTP порт 80.

## Checko vs DaData

| Критерий | Checko | DaData |
|----------|--------|--------|
| ЕГРЮЛ/ЕГРИП | ✅ Полные данные | ✅ Базовые |
| Финансовая отчётность | ✅ ФНС + Росстат | ❌ |
| Госзакупки | ✅ 44-ФЗ / 223-ФЗ | ❌ |
| Арбитраж (КАД) | ✅ | ❌ |
| ФССП | ✅ | ❌ |
| ЕФРСБ (банкротства) | ✅ | ❌ |
| Федресурс | ✅ | ❌ |
| Проверки Генпрокуратуры | ✅ | ❌ |
| Подсказки (autocomplete) | ❌ | ✅ |
| Стандартизация адресов | ❌ | ✅ |
| Цена (бесплатно) | 100 зап./день | 30 зап./день (suggest) |

**Рекомендация для Эверест**: DaData — для подсказок/стандартизации адресов, Checko — для глубокой проверки контрагентов (KYC, due diligence, финансы, суды, ФССП).

## Ограничения и важные замечания

1. Контакты организаций из открытых источников — могут быть неполными/устаревшими
2. ФССП — нечёткий поиск по наименованию, возможны ложные совпадения
3. 223-ФЗ — данные поставщиков не публикуются с 2019 г.
4. `source=true` — добавляет raw ЕГРЮЛ/ЕГРИП данные (точная копия XML→JSON из ФНС)
5. Rate limit — зависит от тарифа (бесплатно 100/день)
