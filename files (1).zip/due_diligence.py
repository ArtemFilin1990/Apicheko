"""
Checko API — Due Diligence скрипт для ООО «Эверест».

Полная проверка контрагента по ИНН:
1. ЕГРЮЛ (company)
2. Финансовая отчётность (finance)
3. Госзакупки (contracts)
4. Арбитражные дела (legal-cases)
5. Исполнительные производства (enforcements)
6. Банкротства ЕФРСБ (bankruptcy-messages)
7. Проверки Генпрокуратуры (inspections)

Вывод: JSON-отчёт с оценкой рисков.

Использование:
    python due_diligence.py --inn 7707049388 --key YOUR_API_KEY
"""

import argparse
import asyncio
import json
import sys
from datetime import datetime

# Requires: pip install httpx
import httpx

BASE_URL = "https://api.checko.ru/v2"


async def fetch(client: httpx.AsyncClient, endpoint: str,
                api_key: str, **params) -> dict:
    """GET-запрос к Checko API с обработкой ошибок."""
    params["key"] = api_key
    try:
        resp = await client.get(f"{BASE_URL}/{endpoint}", params=params)
        resp.raise_for_status()
        data = resp.json()
        if data.get("meta", {}).get("status") == "error":
            return {"error": data.get("meta", {}).get("message", "Unknown")}
        return data.get("data", {})
    except httpx.HTTPStatusError as e:
        return {"error": f"HTTP {e.response.status_code}"}
    except Exception as e:
        return {"error": str(e)}


async def run_due_diligence(inn: str, api_key: str) -> dict:
    """Запуск полной проверки контрагента."""
    report = {
        "inn": inn,
        "timestamp": datetime.now().isoformat(),
        "checks": {},
        "risks": [],
        "risk_level": "LOW",
    }

    async with httpx.AsyncClient(timeout=20.0) as client:
        # 1. ЕГРЮЛ
        company = await fetch(client, "company", api_key, inn=inn)
        report["checks"]["company"] = company

        if "error" not in company:
            name = company.get("name", "[[TBD]]")
            status = company.get("status", {})
            report["company_name"] = name

            # Проверка статуса
            if status and "ликвидир" in str(status).lower():
                report["risks"].append({
                    "factor": "Организация ликвидирована",
                    "severity": "Критическое",
                    "priority": "P0",
                    "detail": f"если заключить договор, то невозможно исполнение"
                })

            # Факторы риска
            risk_data = company.get("risk_factors", {})
            if risk_data:
                if risk_data.get("mass_address"):
                    report["risks"].append({
                        "factor": "Массовый адрес регистрации",
                        "severity": "С",
                        "priority": "P1",
                        "detail": "если адрес массовый, то высока вероятность фирмы-однодневки"
                    })
                if risk_data.get("mass_leader"):
                    report["risks"].append({
                        "factor": "Массовый руководитель",
                        "severity": "В",
                        "priority": "P0",
                        "detail": "если руководитель массовый, то риск номинального управления"
                    })

        # 2. Финансовая отчётность
        finance = await fetch(client, "finance", api_key, inn=inn)
        report["checks"]["finance"] = finance

        # 3. Госзакупки (как поставщик по 44-ФЗ)
        contracts = await fetch(client, "contracts", api_key,
                                inn=inn, law="44", role="supplier", sort="-date")
        report["checks"]["contracts_44fz"] = contracts

        # 4. Арбитражные дела
        legal = await fetch(client, "legal-cases", api_key, inn=inn)
        report["checks"]["legal_cases"] = legal

        # 5. Исполнительные производства
        enforcements = await fetch(client, "enforcements", api_key, inn=inn)
        report["checks"]["enforcements"] = enforcements

        if isinstance(enforcements, list) and len(enforcements) > 0:
            total_debt = sum(
                float(e.get("amount", 0)) for e in enforcements
                if e.get("amount")
            )
            if total_debt > 500_000:
                report["risks"].append({
                    "factor": f"Исполнительные производства: {len(enforcements)} шт., сумма {total_debt:,.0f} руб.",
                    "severity": "В",
                    "priority": "P0",
                    "detail": "если задолженность значительная, то контрагент может не исполнить обязательства"
                })

        # 6. Банкротства
        bankruptcy = await fetch(client, "bankruptcy-messages", api_key, inn=inn)
        report["checks"]["bankruptcy"] = bankruptcy

        if isinstance(bankruptcy, list) and len(bankruptcy) > 0:
            report["risks"].append({
                "factor": f"Записи ЕФРСБ: {len(bankruptcy)} сообщений",
                "severity": "Критическое",
                "priority": "P0",
                "detail": "если есть записи о банкротстве, то высокий риск неплатежа"
            })

        # 7. Проверки Генпрокуратуры
        inspections = await fetch(client, "inspections", api_key, inn=inn)
        report["checks"]["inspections"] = inspections

    # Оценка общего уровня риска
    p0_count = sum(1 for r in report["risks"] if r.get("priority") == "P0")
    if p0_count >= 2:
        report["risk_level"] = "CRITICAL"
    elif p0_count == 1:
        report["risk_level"] = "HIGH"
    elif len(report["risks"]) > 0:
        report["risk_level"] = "MEDIUM"
    else:
        report["risk_level"] = "LOW"

    return report


def main():
    parser = argparse.ArgumentParser(description="Checko Due Diligence")
    parser.add_argument("--inn", required=True, help="ИНН организации")
    parser.add_argument("--key", required=True, help="API-ключ Checko")
    parser.add_argument("--output", default=None, help="Файл для сохранения отчёта")
    args = parser.parse_args()

    report = asyncio.run(run_due_diligence(args.inn, args.key))

    output = json.dumps(report, ensure_ascii=False, indent=2)

    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(output)
        print(f"Отчёт сохранён: {args.output}")
    else:
        print(output)

    # Exit code по уровню риска
    level = report.get("risk_level", "LOW")
    if level == "CRITICAL":
        sys.exit(2)
    elif level == "HIGH":
        sys.exit(1)
    else:
        sys.exit(0)


if __name__ == "__main__":
    main()
